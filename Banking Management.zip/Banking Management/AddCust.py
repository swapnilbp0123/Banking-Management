import pickle

def addcustomer():
            try:
                ac=int(input("Enter Your Account Number: "))
                an=input("Enter Your Name: ")
                bal=float(input("Enter Your Balance: "))
                pin=int(input("Enter Your 4 digit PIN: "))

                lst=list()
                lst.append(ac)
                lst.append(an)
                lst.append(bal)
                lst.append(pin)
                with open("BankingProject.data", "ab") as fp:
                    pickle.dump(lst,fp)
                    print("~" * 50)
                    print("Customer Data Saved Successfully...!")
                    print("~"*50)
            except ValueError:
                print("Invalid Input-Try Again")