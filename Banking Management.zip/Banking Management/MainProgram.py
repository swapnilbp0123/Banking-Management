from AddCust import addcustomer
from Deletecust import deletecustomer
from Viewcust import viewcd, viewcdall
from Deposit import deposit
from Menu import menu
from Searchcust import searchcustomer
from PinUpdate import pinupdate
from Withdraw import withdraw


while True:
    try:
        menu()
        ch=int(input("Enter your choice: "))
        print("~"*50)
        match(ch):
            case 1 :
                addcustomer()
            case 2 :
                withdraw()
            case 3 :
                deposit()
            case 4 :
                deletecustomer()
            case 5 :
                viewcd()
            case 6 :
                viewcdall()
            case 7 :
                searchcustomer()
            case 8 :
                pinupdate()
            case 9 :
                print("Thanx for using the program...!")
                print("~"*50)
                break
            case _:
                print("Your Selection of Operation is Wrong--try again")
                print("~"*50)
    except ValueError:
        print("Please enter a valid choice.")




        """"        for record in records:
            for val in record:
                print(val)"""