import pickle
def searchcustomer():
    with open("BankingProject.data","rb") as fp:
        records = list()
        while True:
            try:
                data = pickle.load(fp)
                records.append(data)
            except EOFError:
                break
    nm=int(input("Enter your Ac no' : "))
    found=False
    for record in records:
        if nm==record[0]:
            found=True
            break
    if found:
        print("~"*50)
        print("\tAccount Found In Banking Project...!")
        print("~" * 50)
    else:
        print("~"*50)
        print("\tAccount NOT Found In Banking Project...!")
        print("~" * 50)
