import pickle

def deposit():
    with open("BankingProject.data","rb") as pd:
        records=list()
        while True:
            try:
                record=pickle.load(pd)
                records.append(record)
            except EOFError:
                break
    eno = int(input("Enter Account Number: "))
    found = False
    for record in range(len(records)):
        if records[record][0] == eno:
            found = True
            rec = record
            break
    if found:
        amt = int(input("Enter Amount: "))
        if amt<=0:
            print("InValid Amount")


        else:
            records[rec][2]+=amt
        with open ("BankingProject.data","wb") as pd:
            for record in records:
                pickle.dump(record,pd)

