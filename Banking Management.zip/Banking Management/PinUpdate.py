import pickle

def pinupdate():
    with open("BankingProject.data","rb")as fp:
        records=list()
        while True:
            try:
                record=pickle.load(fp)
                records.append(record)
            except EOFError:
                break
    emo=int(input("Enter Account Number: "))
    found=False
    for record in records:
        if (record[0]==emo):
            found=True
            rec = record
            break
    if found:
        print("Old PIN Number: ", rec[3])
        np=int(input("Enter New PIN Number: "))
        rec[3]=np
        print(". "*50)
        print("New PIN Number:",np)
        print("PIN Updated Successfully")
        print(". "*50)
        with open("BankingProject.data","wb")as fp:
            for record in records:
                pickle.dump(record,fp)
    else:
        print("Invalid Account No")
