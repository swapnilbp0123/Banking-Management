import pickle

def deletecustomer():
    with open("BankingProject.data","rb") as fp:
        records = list()
        while True:
            try:
                customer = pickle.load(fp)
                records.append(customer)
            except EOFError:
                break
    eno=int(input("Enter Account Number for delete: "))
    found=False
    for record in records:
        if record[0]==eno:
            found=True
            rec= record
            break
    if found:
        records.remove(rec)
        print(". "*50)
        print("Account Deleted Successfully!")
        print(". "*50)
        with open("BankingProject.data","wb") as dl:
            for record in records:
                pickle.dump(record, dl)
    else:
        print("Account Not Found.. Try Again !")

