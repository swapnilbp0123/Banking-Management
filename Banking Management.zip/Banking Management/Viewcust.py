import pickle
def viewcd():
    with open("BankingProject.data", "rb") as fp:
        records = list()
        while (True):
            try:
                record = pickle.load(fp)
                records.append(record)
            except EOFError:
                break
    empno = int(input("Enter Account no:"))
    found = False
    for record in records:
            if record[0] == empno:
                found = True
                rec = record
                break
    if (found):
        print("-" * 50)
        print("\tAccount number:{}".format(rec[0]))
        print("\tAccount holder:{}".format(rec[1]))
        print("\tAmount of Balance:{}".format(rec[2]))
        print("-" * 50)
    else:
        print("\tAccount Does not Exist...")


def viewcdall():
    with open("BankingProject.data", "rb") as fp:
        print("-" * 50)
        print("\tA-C.NO\t\tNAME\t\tBALANCE\t\tPIN")
        print("-" * 50)
        while (True):
            try:
                record = pickle.load(fp)
                # print(record)
                for val in record:
                    print("\t{}".format(val), end="\t")
                print()
            except EOFError:
                print("-" * 50)
                break

# viewcdall()
# viewcd()