import pickle

def withdraw():
    with open("BankingProject.data", "rb") as fp:
        records=list()
        while True:
            try:
                record=pickle.load(fp)
                records.append(record)
            except EOFError:
                break
        eno = int(input("Enter Account Number: "))
        found = False
        for record in range(len(records)):
            if records[record][0] == eno:
                found = True
                rec = record
                break
        if found:
            amt = int(input("Enter Amount: "))
            if amt <= 0:
                print("InValid Amount")
            elif amt + 500 > records[record][2]:
                print("Insufficient Amount")
            else:
                records[rec][2] -= amt
            with open("BankingProject.data", "wb") as pd:
                for record in records:
                    pickle.dump(record, pd)
